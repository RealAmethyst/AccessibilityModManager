// SPDX-License-Identifier: MPL-2.0

#ifdef _WIN32
#if defined(__x86_64) || defined(__x86_64__) || defined(__amd64__) ||          \
    defined(__amd64) || defined(_M_X64) || defined(_M_IX86) ||                 \
    defined(__i386__)
#include "../backend.h"
#include "../backend_catalog.h"
#include "../logging.h"
#include "../optional_library.h"
#include <array>
#include <atomic>
#include <optional>
#include <raw/zdsr.h>
#include <simdutf.h>
#include <string_view>
#include <tchar.h>
#include <tlhelp32.h>
#include <windows.h>

namespace {
#if defined(_M_X64) || defined(__x86_64__)
constexpr const TCHAR *zdsr_dll = _T("ZDSRAPI_x64.dll");
constexpr InstallLocation zdsr_install{
    .subkey = _T("SOFTWARE\\WOW6432Node\\zhiduo\\zdsr"), .value = _T("path")};
#else
constexpr const TCHAR *zdsr_dll = _T("ZDSRAPI.dll");
constexpr InstallLocation zdsr_install{.subkey = _T("SOFTWARE\\zhiduo\\zdsr"),
                                       .value = _T("path")};
#endif

struct Zdsr {
  SharedLibrary library;
  decltype(&::InitTTS) InitTTS;
  decltype(&::Speak) Speak;
  decltype(&::GetSpeakState) GetSpeakState;
  decltype(&::StopSpeak) StopSpeak;
  decltype(&::Braille) Braille;
};

std::optional<Zdsr> load_zdsr() {
  static const LogSource log{"ZDSR"};
  Zdsr api{.library = open_optional_library(zdsr_dll, &zdsr_install)};
  if (!api.library) {
    log.debug(_T("{} could not be loaded"), zdsr_dll);
    return std::nullopt;
  }
  const SharedLibrary &library = api.library;
  const bool complete = library.bind(api.InitTTS, "InitTTS") &&
                        library.bind(api.Speak, "Speak") &&
                        library.bind(api.GetSpeakState, "GetSpeakState") &&
                        library.bind(api.StopSpeak, "StopSpeak") &&
                        library.bind(api.Braille, "Braille");
  if (!complete) {
    log.debug(_T("{} is missing a function prism needs"), zdsr_dll);
    return std::nullopt;
  }
  return api;
}

const Zdsr *zdsr() {
  static const std::optional<Zdsr> api = load_zdsr();
  return api ? &*api : nullptr;
}
} // namespace

class ZdsrBackend final : public TextToSpeechBackend {
private:
  std::atomic_flag initialized;
  const Zdsr *api = nullptr;

  [[nodiscard]] BackendResult<bool> query_speaking() const {
    switch (api->GetSpeakState()) {
    case 3:
      return true;
    case 4:
      return false;
    case 1:
    case 2:
      return std::unexpected(BackendError::BackendNotAvailable);
    case 8:
    case 9:
      return std::unexpected(BackendError::InternalBackendError);
    default:
      return std::unexpected(BackendError::Unknown);
    }
  }

public:
  ~ZdsrBackend() override = default;

  [[nodiscard]] std::string_view get_name() const override { return "ZDSR"; }

  [[nodiscard]] std::bitset<64> get_features() const override {
    using namespace BackendFeature;
    std::bitset<64> features;
    constexpr auto zdsr_processes = std::to_array<std::wstring_view>(
        {_T("ZDSRDaemon.exe"), _T("ZDSRMain.exe"), _T("ZDSRMain_x64.exe"),
         _T("ZDSRMainService.exe"), _T("ZDSRMultiEngine.exe"),
         _T("ZDSRStart.exe")});
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot != INVALID_HANDLE_VALUE) {
      PROCESSENTRY32 entry{};
      entry.dwSize = sizeof(entry);
      if (Process32First(snapshot, &entry)) {
        do {
          if (std::ranges::any_of(zdsr_processes, [entry](const auto &p) {
                return std::wstring_view{entry.szExeFile} == p;
              })) {
            features |= IS_SUPPORTED_AT_RUNTIME;
            break;
          }
        } while (Process32Next(snapshot, &entry));
      }
      CloseHandle(snapshot);
    }
    features |= SUPPORTS_SPEAK | SUPPORTS_OUTPUT | SUPPORTS_IS_SPEAKING |
                SUPPORTS_STOP | SUPPORTS_BRAILLE;
    return features;
  }

  BackendResult<> initialize() override {
    if (initialized.test(std::memory_order_acquire))
      return std::unexpected(BackendError::AlreadyInitialized);
    api = zdsr();
    if (api == nullptr)
      return std::unexpected(BackendError::BackendNotAvailable);
    if (const auto res = api->InitTTS(0, nullptr, TRUE); res > 0)
      return std::unexpected(BackendError::BackendNotAvailable);
    if (const auto state = query_speaking(); !state)
      return std::unexpected(state.error());
    initialized.test_and_set(std::memory_order_release);
    return {};
  }

  BackendResult<> speak(std::string_view text, bool interrupt) override {
    if (!initialized.test(std::memory_order_acquire))
      return std::unexpected(BackendError::NotInitialized);
    const auto len = simdutf::utf16_length_from_utf8(text.data(), text.size());
    std::wstring wstr;
    wstr.resize(len);
    if (const auto res = simdutf::convert_valid_utf8_to_utf16(
            text.data(), text.size(),
            reinterpret_cast<char16_t *>(wstr.data()));
        res == 0)
      return std::unexpected(BackendError::InvalidUtf8);
    if (const auto res = api->Speak(wstr.c_str(), static_cast<BOOL>(interrupt));
        res > 0)
      return std::unexpected(BackendError::InternalBackendError);
    return {};
  }

  BackendResult<> braille(std::string_view text) override {
    if (!initialized.test(std::memory_order_acquire))
      return std::unexpected(BackendError::NotInitialized);
    const auto len = simdutf::utf16_length_from_utf8(text.data(), text.size());
    std::wstring wstr;
    wstr.resize(len);
    if (const auto res = simdutf::convert_valid_utf8_to_utf16(
            text.data(), text.size(),
            reinterpret_cast<char16_t *>(wstr.data()));
        res == 0)
      return std::unexpected(BackendError::InvalidUtf8);
    if (const auto res = api->Braille(wstr.c_str(), FALSE); res > 0)
      return std::unexpected(BackendError::InternalBackendError);
    return {};
  }

  BackendResult<> output(std::string_view text, bool interrupt) override {
    if (const auto res = speak(text, interrupt); !res)
      return res;
    if (const auto res = braille(text); !res)
      return res;
    return {};
  }

  BackendResult<> stop() override {
    if (!initialized.test(std::memory_order_acquire))
      return std::unexpected(BackendError::NotInitialized);
    api->StopSpeak();
    return {};
  }

  BackendResult<bool> is_speaking() override {
    if (!initialized.test(std::memory_order_acquire))
      return std::unexpected(BackendError::NotInitialized);
    return query_speaking();
  }
};

REGISTER_BACKEND_WITH_ID(ZdsrBackend, Backends::ZDSR, "ZDSR", 101);
#endif
#endif
