# Summary

- [Introduction](./introduction.md)
- [Wine Bridges](./wine-bridges.md)

# API Reference

- [Overview](./api/overview.md)
- [Conventions](./api/conventions.md)
- [Thread Safety](./api/thread-safety.md)
- [Error Codes](./api/error-codes.md)
- [Backend limits](./api/backend-limits.md)
- [Backend Identifiers](./api/backend-identifiers.md)
- [Context Management](./api/context-management.md)
- [Backend Registry Functions](./api/registry-functions.md)
- [Backend Functions](./api/backend-functions.md)
- [Backend Availability Enumeration](./api/backend-enumeration.md)
- [Custom Backends](./api/custom-backends.md)
- [Shared Library Backends](./api/shared-library-backends.md)
- [Voice Parameters](./api/voice-parameters.md)
- [Voice Selection](./api/voice-selection.md)
- [Audio Format](./api/audio-format.md)
- [Utilities](./api/utilities.md)
- [Audio Callback](./api/audio-callback.md)
- [Logging](./api/logging.md)
- [Backend-specific notes](./api/backend-notes.md)
